from django.shortcuts import render
from django.http import HttpResponseRedirect
#from django.core.urlresolvers import reverse
from .animedetails import Anime, AnimeForm
import uuid

# Create your views here.
def full_anime_listing(request):
    allAnimes = Anime.objects.all()
    return render(request, 'animedetails/listAnime.html', {
        'animedetails': allAnimes,
    })

def add_anime(request):
    animeForm = AnimeForm()

    if request.method == 'POST':
        animeForm = AnimeForm(request.POST, request.FILES)
        if animeForm.is_valid():
            anime = Anime()
            anime.name = animeForm.cleaned_data['name']
            anime.genre= animeForm.cleaned_data['genre']
            anime.anime_type = animeForm.cleaned_data['anime_type']
            anime.episodes = animeForm.cleaned_data['episodes']
            anime.rating = animeForm.cleaned_data['rating']
            anime.members = animeForm.cleaned_data['members']
            anime.anime_photo = animeForm.cleaned_data['anime_photo']
            anime.save()
            return HttpResponseRedirect("/")
    
    return render(request, 'animedetails/addAnime.html', {'form': animeForm})

def view_animedetails(request):
    # anime_id = request.POST.get('Anime.anime_id')
    animes = Anime.objects.all().filter(id__exact = Anime.anime_id)
    # animes = Anime.objects.get(anime_id)
    #animeID = animes.anime_id.replace('-', '')
    
    #allAnimes = Anime.objects.all()
    return render(request, 'animedetails/listAnimeDetails.html', {
        'animedetails': animes,
    })
        

# def anime_details(request):
#     if request.method == 'POST':
#         anime_id = request.POST.get('anime_id')
#         return redirect(reverse('view_animedetails', args = (anime_id,)))
