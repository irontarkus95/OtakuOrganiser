from django.shortcuts import render
from django.http import HttpResponseRedirect
from .animedetails import Anime, AnimeForm

# Create your views here.
def full_anime_listing(request):
    allAnimes = Anime.objects.all()
    return render(request, 'animedetails/listAnime.html', {
        'animedetails': allAnimes,
    })

def add_anime(request):
    animeForm = AnimeForm()

    if request.method == 'POST':
        animeForm = AnimeForm(request.POST, request.FILES)
        if animeForm.is_valid():
            anime = Anime()
            anime.name = animeForm.cleaned_data['name']
            anime.genre= animeForm.cleaned_data['genre']
            anime.anime_type = animeForm.cleaned_data['anime_type']
            anime.episodes = animeForm.cleaned_data['episodes']
            anime.rating = animeForm.cleaned_data['rating']
            anime.members = animeForm.cleaned_data['members']
            anime.anime_photo = animeForm.cleaned_data['anime_photo']
            anime.save()
            return HttpResponseRedirect("/")
    
    return render(request, 'animedetails/addAnime.html', {'form': animeForm})
