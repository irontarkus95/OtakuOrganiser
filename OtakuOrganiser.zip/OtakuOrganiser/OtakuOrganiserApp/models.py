from django.db import models

# Create your models here.
from OtakuOrganiserApp.animedetails import Anime
