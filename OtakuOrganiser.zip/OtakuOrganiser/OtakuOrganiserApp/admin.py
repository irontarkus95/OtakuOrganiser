from django.contrib import admin

# Register your models here.
from .animedetails import Anime
admin.site.register(Anime)