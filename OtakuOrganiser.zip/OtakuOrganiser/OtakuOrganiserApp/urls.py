from django.conf.urls import url
from django.urls import path
from .animedetails import Anime
from .import views

urlpatterns = [
    path('', views.full_anime_listing, name = 'anime_full_list'),
    path('anime/new/', views.add_anime, name = 'anime_new'),
    path('anime/<uuid: pk>/', views.view_animedetails, name = 'anime_details' )
]