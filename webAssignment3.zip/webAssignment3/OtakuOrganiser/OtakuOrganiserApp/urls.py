from django.conf.urls import url
from django.urls import path
from .animes import Anime
from .import views

urlpatterns = [
    path('', views.full_anime_listing, name = 'anime_full_list'),
    path('anime/new/', views.add_anime, name = 'anime_new'),
    # path('anime/details/', views.view_animedetails, name = 'anime_details' )
]


# I LOVE WO! WILL WO MAWWY MWE? :3 I WILL MISS WO SHO MUCH MY SWEETHEART, PLEASE DON'T STRESS OUT SO MUoOMCMH OKAY it's not worth it :( i gonna MAWWY WOO ALL OVER WHYY 
#WOO SHO SWEET FOR! :') WOO DONT STRESS OUT TOO MUCH TOO SWEETHEART <3 I LOVE WOO SHOOOO MUCH! I CANT WAIT TO MAWWY WOO :') AND TRAVEL EVERYWHERE WITH WOO
# My sweetheart yes! All this right now is just a little roadblock. We'll get past it. This is nothing. There's so much more waiting for us :)
#:') Wah I no done yet  :waPhHH sO DON'T LOSE Hope baby. Don't think of this as our failure. Shit happens that is out of our control. :aOLL THAT MATTERS IF THAT we have each other :)
#BABY 