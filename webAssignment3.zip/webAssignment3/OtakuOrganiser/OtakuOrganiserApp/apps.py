from django.apps import AppConfig


class OtakuorganiserappConfig(AppConfig):
    name = 'OtakuOrganiserApp'
