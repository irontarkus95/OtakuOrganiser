from django.db import models

# Create your models here.
from OtakuOrganiserApp.animes import Anime