import uuid
from django.db import models
#from django.contrib.postgres.fields import ArrayField
from django.db.models import (
    UUIDField,
    CharField,
    IntegerField,
    BigIntegerField,
    FloatField,
    ImageField
)

class Anime(models.Model):
    anime_id = UUIDField(primary_key=True, default=uuid.uuid4, editable =False)
    name = CharField(max_length = 100)
    genre = CharField(max_length = 200)

    MOVIE = "Movie"
    TV = "TV"
    OVA = "OVA"
    SPECIAL = "Special"

    GENRE_CHOICE = (
        (MOVIE, "Movie"),
        (TV, "TV"),
        (OVA, "OVA"),
        (SPECIAL, "Special")
    )

    anime_type = CharField(
        max_length = 7,
        choices = GENRE_CHOICE,
        default = TV,
    )

    episodes = IntegerField()
    rating = FloatField(default = 0)
    members = BigIntegerField()

    anime_photo = ImageField(null = True, upload_to = 'img/profiles', verbose_name = "Anime Photo")

    class Meta:
        ordering = ('rating',)